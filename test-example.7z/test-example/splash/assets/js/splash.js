var $canvas = $("#grid");
var canvas = $canvas.get(0);
var ctx = canvas.getContext("2d");
 //var img = document.getElementById("bg");
 //ctx.drawImage(img,0,0);
//ctx.fillStyle = "#1a273d";
ctx.fillStyle = "#17263b0a";

	//var r_a =  0.1;
//ctx.fillStyle = "rgba(255, 255, 255, " + r_a + ")";
//ctx.strokeStyle = "rgba(255, 255, 255, 0.1)";
ctx.lineWidth = 1;

var width = canvas.width;
var height = canvas.height;
var diameter = width - (width * 0);
var radius = diameter / 2;
var center = { x: width / 2, y: height / 2 };
var length = 64;

var spin = 4000;
var spintarget = Math.PI * 2;

var colorspeed = 300;
var rainbow = makeColorGradient(length);

var target = {
  x: Math.random() * width,
  y: Math.random() * height,
  start: 0,
  last: {
    x: Math.random() * width,
    y: Math.random() * height
  }
};

var points = new Array(length);

$.each(points, function(i, point) {
  var theta = (360 / length * i) * Math.PI / 180;
  point = {};
  point.x = radius * Math.cos(theta) + center.x;
  point.y = radius * Math.sin(theta) + center.y;
  point.t = theta;
  points[i] = point;
});

window.requestAnimationFrame(drawFrame);

function drawFrame (timestamp) {
  var r = Math.floor(timestamp / colorspeed);
  if (target.start === 0) {
    target.start = timestamp;
  }
  var theta = linearEase(timestamp, 0, spintarget, spin) % spintarget;
  ctx.fillRect(0, 0, width, height);
  $.each(points, function(i, point) {
    ctx.beginPath();
    var c = rainbow[(r + i) % rainbow.length];
    ctx.strokeStyle = "rgba(" + c.r + ", " + c.g + ", " + c.b + ", 0.4)";
    var pt = point.t + theta;
    var px = radius * Math.cos(pt) + center.x;
    var py = radius * Math.sin(pt) + center.y;
    ctx.moveTo(px, py);
    ctx.lineTo(point.x, point.y);
  ctx.stroke();
  });
  window.requestAnimationFrame(drawFrame);
}

function linearEase(ci, sv, civ, ti) {
  return civ * ci / ti + sv;
}

function makeColorGradient(len) {
  var f1 = 2*Math.PI/len;
  var f2 = f1;
  var f3 = f1;
  var p1 = 0;
  var p2 = 2;
  var p3 = 4;
  var c = 128;
  var w = 127;
  var a = [];
  for (var i = 0; i < len; ++i) {
    var r = Math.round(Math.sin(f1 * i + p1) * w + c);
    var g = Math.round(Math.sin(f2 * i + p2) * w + c);
    var b = Math.round(Math.sin(f3 * i + p3) * w + c);
    a.push({ r: r, g: g, b: b});
  }
  return a;
}