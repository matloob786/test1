(function($) {
  $.fn.autocomplete = function(words, output) {
    var startsWith = function(letters) {
      return function(word) {
        return word.indexOf(letters) === 0;
      }
    }

    var matches = function(letters) {
      return letters ?
        $.grep(words, startsWith(letters)) : [];
    }

    this.keyup(function() {
      var letters = $(this).val();
      output(letters, matches(letters));
    });
  };
})(jQuery);

var words = [
  'random', 'list', 'of', 'words',
  'draisine', 'swithe', 'overdiversification', 'bitingness',
  'misestimation', 'mugger', 'fissirostral', 'oceanophyte',
  'septic', 'angletwitch', 'brachiopod', 'autosome',
  'uncredibility', 'epicyclical', 'causticize', 'tylotic',
  'robustic', 'chawk', 'mortific', 'histotomy',
  'slice', 'enjambment', 'mercaptids', 'oppositipetalous',
  'impious', 'pollinivorous', 'poulaine', 'wholesaler'
];

var render = function($output) {
  return function(letters, matches) {
    $output.empty()

    if(matches.length) {
      var $highlight = $('<span/>')
        .text(letters)
        .addClass('highlight');

      $.each(matches, function(index, match) {
        var remaining = match.replace(letters, '');
        $match = $('<li/>')
          .append($highlight.clone(), remaining)
          .addClass('match');
        $output.append($match);
      });
    }
  }
}

$(document).ready(function() {
  $('input').autocomplete(words.sort(), render($('.matches')));
});